import pymysql
import json
class fenshuduan(object):
    def __init__(self,xueixoaid,exam_id,zuhe,kelei):
        self.xueixoaid=xueixoaid
        self.exam_id =exam_id
        self.kelei=kelei
        self.zuhe=zuhe
        self.all_xueke = {
            '100003': "物理",
            '100004': "化学",
            '100007': "政治",
            '100005': "生物",
            '100008': "地理",
            '100002': '数学',
            '100001': "语文",
            '100016': "英语",
            '100006': "历史"
        }
        self.xueke_d={}
        for k,i in self.all_xueke.items():
            self.xueke_d[i]= k
        if kelei == '物理' and zuhe == '全部':
            self.zuhe=['物理','语文','数学','英语','化学','生物']
        if kelei == '历史' and zuhe == '全部':
        if zuhe!='全部':
            self.zuhe=zuhe
    #分段统计
    def zongfen(self,begin_fem,end_fen):
        conn = pymysql.connect(host='rm-2zeo67yg67a61ancn4o.mysql.rds.aliyuncs.com',
                               user='QA',password='hmk#%^&djofsdh',database='exam_business2',charset='utf8')
        sql = 'SELECT subject_code,class_name,class_code,subject_code,student_code,total_score,school_code  FROM stu_subject_score WHERE exam_id= %s AND school_code = %s  ' %\
              ( str(self.exam_id),str(self.xueixoaid))
        cursor = conn.cursor()
        cursor.execute(sql)
        all_data=cursor.fetchall()
        xuexia_num=0
        banji_bun=0
        wuli_st=[]
        lishi_st=[]
        for i in all_data:
            if i[0] == '100003':
                wuli_st.append(i[4])
            elif i[0] == '100006':
                lishi_st.append(i[4])
        all_student_data={}
        for i in all_data:
                if self.kelei =='物理':
                    if i[4] in wuli_st:
                        if i[4] not in all_student_data.keys():
                            all_student_data[i[4]] = {
                                'score':0,
                                "class_name": i[1],
                                'school_code':i[6],
                            }
                        else:
                                all_student_data[i[4]]['score'] = all_student_data[i[4]]['score'] + i[5]
                elif self.kelei =='历史':
                    if i[4] in lishi_st:
                        if i[4] not in all_student_data.keys():
                            all_student_data[i[4]] = {
                                'score':0,
                                "class_name": i[1],
                                'school_code':i[6],
                            }
                        else:
                                all_student_data[i[4]]['score'] = all_student_data[i[4]]['score'] + i[5]
        student_id_lianem=[]
        print (sorted([all_student_data[i]['score'] for i in all_student_data],reverse=True))
        return_num_lianmeng=0
        student_id_xuexiao=[]
        return_num_xuexiao = 0
        for k,i in all_student_data.items():
            if begin_fem <i['score']<=end_fen:
                if int(i['school_code']) == int (self.xueixoaid):
                    student_id_xuexiao.append(k)
                    return_num_xuexiao+=1
        return {
            '学校': {
                "满足条件人数": return_num_xuexiao,
                '详情': student_id_xuexiao
            },
        }
if __name__=='__main__':
    xueixoaid = '1541982701274267648'
    exam_id ='2962825620455424'
    kelei= "历史"
    zuhe="全部"
    x=fenshuduan(xueixoaid,exam_id,zuhe,kelei)
    print (x.zongfen(320,330))





