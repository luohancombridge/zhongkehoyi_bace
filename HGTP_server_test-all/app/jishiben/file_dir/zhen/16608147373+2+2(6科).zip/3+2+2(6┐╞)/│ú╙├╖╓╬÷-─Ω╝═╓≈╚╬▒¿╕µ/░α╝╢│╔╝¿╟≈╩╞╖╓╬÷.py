import pymysql
import json
class fenshuduan(object):
    def __init__(self,xueixoaid,exam_id,kemu):
        self.keumu = kemu
        self.xueixoaid=xueixoaid
        self.exam_id =exam_id
        self.all_xueke = {
            '100003': "物理",
            '100004': "化学",
            '100007': "政治",
            '100005': "生物",
            '100008': "地理",
            '100002': '数学',
            '100001': "语文",
            '100016': "英语",
            '100006': "历史"
        }
        self.xueke_d={}
        for k,i in self.all_xueke.items():
            self.xueke_d[i]= k
        if kemu!='总分':
            self.keumu = []
            for i in kemu:
              self.keumu.append( self.xueke_d[i])
    #分段统计
    def zongfen(self):
        conn = pymysql.connect(host='rm-2zeo67yg67a61ancn4o.mysql.rds.aliyuncs.com',
                               user='QA',password='hmk#%^&djofsdh',database='exam_business2',charset='utf8')
        sql = 'SELECT subject_code,class_edu_name,class_edu_code,subject_code,student_code,total_score,school_code,student_name  FROM stu_subject_score WHERE exam_id= %s  ' %\
              ( str(self.exam_id))
        cursor = conn.cursor()
        cursor.execute(sql)
        all_data=cursor.fetchall()
        xuexia_num=0
        banji_bun=0
        wuli_st=[]
        lishi_st=[]
        all_student_data={}
        for i in all_data:
                if i[0]  in self.keumu:
                                if i[4] not in all_student_data.keys():
                                    all_student_data[i[4]] = {
                                        "student_name":i[7],
                                        'score':i[5],
                                        "class_name": i[1],
                                        "class_code": i[2],
                                        'school_code':i[6],
                                    }
                                else:
                                        all_student_data[i[4]]['score'] = all_student_data[i[4]]['score'] + i[5]
        return_data={}
        print (all_student_data)
        for k,i in all_student_data.items():
               if i['class_name']  not in return_data.keys():
                   return_data[i['class_name']]={
                       "total":i['score'],
                       'num':1
                   }
               else:
                   return_data[i['class_name']]['total'] =  return_data[i['class_name']]['total'] + i['score']
                   return_data[i['class_name']]['num']+=1
        retuir_dd={}
        for k , i in return_data.items():
            return_data[k]['平均分'] =  return_data[k]['total']/return_data[k]['num']
        return return_data
    # 查询这个分数，是多少名次，fenshu是分数值，scorelist 是分数得列表
    def get_fen(self, fenshu, scorelist):
        for k, i in enumerate(sorted(scorelist,reverse=True)):
            if k == 0:
                mingci = 1
                mingcifen = i
            else:
                if i == mingcifen:
                    continue
                else:
                    mingci = mingci + 1
                    mingcifen = i
            if mingcifen == fenshu:
                break
        return mingci
if __name__=='__main__':
    xueixoaid = '1541982701274267648'
    exam_id ='2962825620455424'
    kemu=['语文']
    x=fenshuduan(xueixoaid,exam_id,kemu)
    print (x.zongfen())




