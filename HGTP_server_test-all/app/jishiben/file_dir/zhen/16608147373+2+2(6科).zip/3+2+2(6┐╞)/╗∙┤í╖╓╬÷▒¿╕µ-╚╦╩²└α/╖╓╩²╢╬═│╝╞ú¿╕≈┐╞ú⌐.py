import pymysql
import json
class fenshuduan(object):
    def __init__(self,xueixoaid,exam_id,banji_name,xueke,fenshu_type):
        self.fenshu_type = fenshu_type
        self.xueixoaid=xueixoaid
        self.exam_id =exam_id
        self.banji_name = banji_name
        self.xueke = xueke
        self.all_xueke = {
            '100003': "物理",
            '100004': "化学",
            '100007': "政治",
            '100005': "生物",
            '100008': "地理",
            '100002': '数学',
            '100001': "语文",
            '100016': "英语",
            '100006': "历史"
        }
        self.xueke_d={}
        for k,i in self.all_xueke.items():
            self.xueke_d[i]= k
        self.xueke=self.xueke_d[xueke]
    #分段统计
    def zongfen(self,begin_fem,done_fen):
        conn = pymysql.connect(host='rm-2zeo67yg67a61ancn4o.mysql.rds.aliyuncs.com',
                               user='QA',password='hmk#%^&djofsdh',database='exam_business2',charset='utf8')
        sql = 'SELECT subject_code,class_name,class_code,subject_code,student_code,total_score  FROM stu_subject_score WHERE exam_id= %s  and school_code= %s ' %\
              ( str(self.exam_id), str(self.xueixoaid))
        cursor = conn.cursor()
        cursor.execute(sql)
        all_data=cursor.fetchall()
        xuexia_num=0
        banji_bun=0
        all_student_data={}
        for i in all_data:
            if i[0] == self.xueke:
                        all_student_data[i[4]] = {
                            'score':i[5],
                            "class_name": i[1]
                        }
        for k,i in all_student_data.items():
            if fenshu_type=='分段统计':
                if begin_fem<i['score'] <=done_fen:
                    xuexia_num = xuexia_num +1
                    if i['class_name'] == self.banji_name :
                        banji_bun = banji_bun +1
            else:
                if begin_fem<=i['score']:
                    xuexia_num = xuexia_num +1
                    if i['class_name'] == self.banji_name :
                        banji_bun = banji_bun +1
        return {
            "学校人数":xuexia_num,
            "班级人数":banji_bun
        }
if __name__=='__main__':
    xueixoaid = '1541982701274267648'
    exam_id ='2963037883039744'
    banji_name='甲校B班'
    xueke = "语文"
    fenshu_type="累计统计"
    x=fenshuduan(xueixoaid,exam_id,banji_name,xueke,fenshu_type)
    print (x.zongfen(120,20))





