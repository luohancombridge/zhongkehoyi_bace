import pymysql
import json
class fenshuduan(object):
    def __init__(self,xueixoaid,exam_id,banji_name,xueke,paimingfanwei):
        self.paimingfanwei = paimingfanwei
        self.xueixoaid=xueixoaid
        self.exam_id =exam_id
        self.banji_name = banji_name
        self.xueke = xueke
        self.all_xueke = {
            '100003': "物理",
            '100004': "化学",
            '100007': "政治",
            '100005': "生物",
            '100008': "地理",
            '100002': '数学',
            '100001': "语文",
            '100016': "英语",
            '100006': "历史"
        }
        self.xueke_d={}
        for k,i in self.all_xueke.items():
            self.xueke_d[i]= k
        self.xueke=self.xueke_d[xueke]
    #分段统计
    def zongfen(self,begin_fem,end_fen):
        conn = pymysql.connect(host='rm-2zeo67yg67a61ancn4o.mysql.rds.aliyuncs.com',
                               user='QA',password='hmk#%^&djofsdh',database='exam_business2',charset='utf8')
        sql = 'SELECT subject_code,class_name,class_code,subject_code,student_code,total_score,school_code  FROM stu_subject_score WHERE exam_id= %s  and subject_code= "%s" ' %\
              ( str(self.exam_id), self.xueke)
        cursor = conn.cursor()
        cursor.execute(sql)
        all_data=cursor.fetchall()
        all_student_data={}
        for i in all_data:
                        all_student_data[i[4]] = {
                            'score':i[5],
                            "class_name": i[1],
                            'school_code':i[6],
                        }
        if self.paimingfanwei == '学校':
            all_score_list=sorted([i['score'] for k,i in all_student_data.items() if i['school_code']==int(self.xueixoaid)],reverse=True)
        else:
            all_score_list = sorted(
                [i['score'] for k, i in all_student_data.items() ], reverse=True)
        banji_score_list=sorted([i['score'] for k,i in all_student_data.items() if i['school_code']==int(self.xueixoaid) and i['class_name'] == self.banji_name],reverse=True)
        zz=self.get_fen(begin_fem,end_fen,all_score_list)
        if zz=='名次不够':
            return zz
        begin_fen,end_fen = self.get_fen(begin_fem,end_fen,all_score_list)
        this_num=0
        thisasdfa=[]
        for k,i in enumerate(banji_score_list):
            if   begin_fen<=i<end_fen:
                thisasdfa.append(i)
                this_num+=1
        print (banji_score_list)
        print (thisasdfa)
        return {
            "进入排名人数":this_num
        }
    #获取这个排名段，起始分数，结束分数,scorelists是所有学生单单分数的列表
    def get_fen(self,begin_ci,end_ci,scorelist):
        print (scorelist)
        if begin_ci==1:
            end_fen = scorelist[0]
        else:
            if  scorelist[begin_ci-2] == scorelist[begin_ci-1]:
                for k,i in enumerate(scorelist[begin_ci:]):
                    if i!=scorelist[begin_ci-1]:
                        end_fen = i
                        break
            else:
                end_fen = scorelist[begin_ci-1]
        if len(scorelist)<end_ci:
            end_ci = len(scorelist)
        if scorelist[end_ci - 2] == scorelist[end_ci - 1]:
            for i in scorelist[end_ci:]:
                if i != scorelist[end_ci - 1]:
                    begin_fem =  scorelist[end_ci - 1]
                    break
        else:
            begin_fem = scorelist[end_ci - 1]
        print (begin_fem,end_fen)
        return begin_fem,end_fen
if __name__=='__main__':
    xueixoaid = '1541982701274267648'
    exam_id ='2963037883039744'
    banji_name='甲校B班'
    xueke = "数学"
    paimingfanwei='学校'
    x=fenshuduan(xueixoaid,exam_id,banji_name,xueke,paimingfanwei)
    print (x.zongfen(20,30))





