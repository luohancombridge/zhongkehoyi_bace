import pymysql
import json
class fenshuduan(object):
    def __init__(self,xueixoaid,exam_id,kemu,kele):
        self.kele =kele
        self.xueixoaid=xueixoaid
        self.exam_id =exam_id
        self.kumu = kemu
        self.all_xueke = {
            '100003': "物理",
            '100004': "化学",
            '100007': "政治",
            '100005': "生物",
            '100008': "地理",
            '100002': '数学',
            '100001': "语文",
            '100016': "英语",
            '100006': "历史"
        }
        self.xueke_d={}
        for k,i in self.all_xueke.items():
            self.xueke_d[i]= k
        if kemu!='总分':
            self.keumu=[]
            for  i in kemu:
                self.keumu.append(self.xueke_d[i])
        else:
            self.keumu = self.xueke_d.values()
    #分段统计
    def zongfen(self):
        conn = pymysql.connect(host='rm-2zeo67yg67a61ancn4o.mysql.rds.aliyuncs.com',
                               user='QA',password='hmk#%^&djofsdh',database='exam_business2',charset='utf8')
        sql = 'SELECT subject_code,class_name,class_code,subject_code,student_code,total_score,school_code,student_name  FROM stu_subject_score WHERE exam_id= %s  ' %\
              ( str(self.exam_id))
        cursor = conn.cursor()
        cursor.execute(sql)
        all_data=cursor.fetchall()
        xuexia_num=0
        banji_bun=0
        wuli_st=[]
        lishi_st=[]
        for i in all_data:
            if i[0] == '100003':
                wuli_st.append(i[4])
            elif i[0] == '100006':
                lishi_st.append(i[4])
        if self.kele == '物理':
            stud_code_akl=wuli_st
        else:
            stud_code_akl = lishi_st
        all_student_data={}
        print (self.keumu)
        for i in all_data:
            if i[5] !=0:
                    if self.keumu=='总分':
                         if   i[4]  in stud_code_akl:
                                        if i[4] not in all_student_data.keys():
                                            all_student_data[i[4]] = {
                                                'student_code':i[4],
                                                "student_name":i[7],
                                                'score':i[5],
                                                "class_name": i[1],
                                                'school_code':i[6],
                                            }
                                        else:
                                                all_student_data[i[4]]['score'] = all_student_data[i[4]]['score'] + i[5]
                    else:
                        if i[0] in self.keumu:
                            if i[4] in stud_code_akl:
                                        if i[4] not in all_student_data.keys():
                                            all_student_data[i[4]] = {
                                                'student_code': i[4],
                                                "student_name": i[7],
                                                'score': i[5],
                                                "class_name": i[1],
                                                'school_code': i[6],
                                            }
                                        else:
                                            all_student_data[i[4]]['score'] = all_student_data[i[4]]['score'] + i[5]
        return_data={
            "联考":{
                'total':0,
                'num':0
            },
            "年级": {
                'total': 0,
                'num': 0
            },
        }
        for k,i in all_student_data.items():
            return_data['联考']['total'] = return_data['联考']['total'] + i['score']
            return_data['联考']['num'] = return_data['联考']['num'] + 1
            if i['school_code'] == int(self.xueixoaid):
                return_data['年级']['total'] = return_data['年级']['total'] + i['score']
                return_data['年级']['num'] = return_data['年级']['num'] + 1
            if i['class_name'] not in return_data.keys():
                return_data[i['class_name']]={
                    'total': i['score'],
                     'num':1
                }
            else:
                return_data[i['class_name']]['total'] = return_data[i['class_name']]['total']  + i['score']
                return_data[i['class_name']]['num'] = return_data[i['class_name']]['num'] + 1
        return_ddd={}
        for k,i in return_data.items():
             return_ddd[k]=return_data[k]['total']/return_data[k]['num']
        return return_ddd
if __name__=='__main__':
    xueixoaid = '1541982701274267648'
    exam_id ='2962825620455424'
    kele='历史'
    kemu='总分'
    x=fenshuduan(xueixoaid,exam_id,kemu,kele)
    print (x.zongfen())




