import pymysql
import json
class fenshuduan(object):
    def __init__(self,exam_id,xueixoaid,xueke,leixing,banjiming):
        self.xueke = xueke
        self.xueixoaid=xueixoaid
        self.exam_id =exam_id
        self.leixing = leixing
        self.xueke = xueke
        self.banjiming = banjiming
        self.all_xueke = {
            '100003': "物理",
            '100004': "化学",
            '100007': "政治",
            '100005': "生物",
            '100008': "地理",
            '100002': '数学',
            '100001': "语文",
            '100016': "英语",
            '100006': "历史"
        }
        self.xueke_d={}
        for k,i in self.all_xueke.items():
            self.xueke_d[i]= k
        self.xueke=self.xueke_d[xueke]
    #分段统计
    def zongfen(self):
        conn = pymysql.connect(host='rm-2zeo67yg67a61ancn4o.mysql.rds.aliyuncs.com',
                               user='QA',password='hmk#%^&djofsdh',database='exam_business2',charset='utf8')
        sql = 'SELECT subject_code,class_name,class_code,subject_code,student_code,total_score ,school_code FROM stu_subject_score WHERE exam_id= %s  and ' \
              'subject_code = %s  ' %\
              ( str(self.exam_id),str(self.xueke))
        cursor = conn.cursor()
        cursor.execute(sql)
        all_data=cursor.fetchall()
        xuexia_num=0
        banji_bun=0
        all_student_data={}
        for i in all_data:
            if i[0] == self.xueke:
                        all_student_data[i[4]] = {
                            'score':i[5],
                            "class_name": i[1],
                            'xuexiao':i[6]
                        }
        liankao={
            'num': 0,
            "total":0,
            "zuigao":0,
            "zuidi":0,
            "pingjun":0,
            "0fen":0,
        }
        xuexiao = {
            'num':0,
            "total": 0,
            "zuigao": 0,
            "zuidi": 0,
            "pingjun": 0,
            "0fen":0,
        }
        banji = {
            'num':0,
            "total": 0,
            "zuigao": 0,
            "zuidi": 0,
            "pingjun": 0
        }
        banji = {

        }
        for k,i in all_student_data.items():
              if  i['score']==0:
                  liankao['0fen']= liankao['0fen'] +1
                  if i['xuexiao'] == self.xueixoaid:
                      xuexiao['0fen'] = xuexiao['0fen'] + 1
                  if i["class_name"] not in banji.keys():
                      banji[i["class_name"]] = {
                          'num': 0,
                          "total": 0,
                          "zuigao": 0,
                          "zuidi": 0,
                          "pingjun": 0,
                          '0fen':1
                      }
                  else:
                      banji[i["class_name"]]['0fen'] = banji[i["class_name"]]['0fen']  +1
              else:
                  liankao['num'] =   liankao['num']  +1
                  liankao['total'] = liankao['total'] + i['score']
                  if liankao['zuigao'] < i['score']:
                    liankao['zuigao'] = i['score']
                  if liankao['zuidi']  == 0:
                      liankao['zuidi'] = i['score']
                  elif liankao['zuidi'] > i['score']:
                    liankao['zuidi'] = i['score']
                  if i['xuexiao'] == self.xueixoaid:
                      xuexiao['num'] = xuexiao['num'] + 1
                      xuexiao['total'] = xuexiao['total'] + i['score']
                      if  xuexiao['zuigao']  <i['score']:
                          xuexiao['zuigao'] = i['score']
                      if xuexiao['zuidi'] == 0:
                          xuexiao['zuidi'] = i['score']
                      elif xuexiao['zuidi'] > i['score']:
                          xuexiao['zuidi'] = i['score']
                      if i[ "class_name"] not in banji.keys():
                          banji[i[ "class_name"]]  = {
                              'num':1,
                              "total": i['score'],
                              "zuigao": i['score'],
                              "zuidi": i['score'],
                              "pingjun": i['score'],
                              '0fen': 0
                          }

                      else:
                          banji[i[ "class_name"]]['num'] = banji[i[ "class_name"]]['num'] + 1
                          banji[i["class_name"]]['total'] =  banji[i["class_name"]]['total']  +  i['score']
                          if banji[i["class_name"]]['zuigao'] < i['score']:
                              banji[i["class_name"]]['zuigao'] = i['score']
                          if banji[i["class_name"]]['zuidi'] > i['score']:
                              banji[i["class_name"]]['zuidi'] = i['score']
        liankao['pingjun']=liankao['total']/liankao['num']
        xuexiao['pingjun'] = xuexiao['total'] / xuexiao['num']
        for k,i in banji.items():
            banji[k]['pingjun'] =   banji[k]['total'] /   banji[k]['num']
        return {
            "联考":liankao,
            "学校":xuexiao,
            "班级":banji
        }
if __name__=='__main__':
     exam_id=2962825620455424
     xuexiaoid=1541982701274267648
     xueke='历史'
     leixing='行政班'
     banjiming='甲校A班'
     x=fenshuduan(exam_id,xuexiaoid,xueke,leixing,banjiming)
     b=x.zongfen()
     print (b)





